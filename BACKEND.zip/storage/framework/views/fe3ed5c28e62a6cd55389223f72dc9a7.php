<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Pengingat Absen</title>
</head>
<body>
    <p>Halo <?php echo e($nama ?? 'User'); ?>,</p>
    <p><?php echo nl2br(e($pesan ?? 'Anda belum melakukan absen atau izin hari ini.')); ?></p>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/Presensi-Indogreen-main/resources/views/emails/pengingat_absen.blade.php ENDPATH**/ ?>